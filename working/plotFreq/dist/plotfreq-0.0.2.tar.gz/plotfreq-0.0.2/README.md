Lecture 08 - create module out of an exercise
taking Lecture 03 Q6 as example